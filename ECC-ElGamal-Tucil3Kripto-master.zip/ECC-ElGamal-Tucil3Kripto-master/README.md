# ECC-ElGamal-Tucil3Kripto
An ElGamal Elliptic Curve Cryptography implementation using java with GUI
